<template>
  <div>
    <div class="card mt-2">
      <img
        src="https://mblogthumb-phinf.pstatic.net/MjAyMjA4MjZfMjY2/MDAxNjYxNDU1NzgxNTE5.HBaQffQjTAFckk9zk50VE6i64Rn77HHNH2M9TeJBC3Ug.rPh_OYsBOOwIYfXAuv8m_YpapOpXbgFUmplo8j-owG4g.JPEG.shel8979/IMG_5593.jpg?type=w800"
        class="card-img-top"
        alt="..."
      />
      <div class="card-body">
        <h5 class="card-title">Blog</h5>
        <p class="card-text">
          Some quick example text to build on the card title and make up the bulk of the card's
          content.
        </p>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>
</template>
